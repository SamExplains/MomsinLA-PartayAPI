<?php $__env->startSection('title', 'MomsinLA'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="col-12 text-center mt-4">
        <img src="<?php echo e(asset('img/donations/left.jpg')); ?>" class="img-fluid" alt="">
    </div>

    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 mt-2 mb-2 p-3" style="border: 1px solid rgba(0, 0, 0, 0.150);">
            <div class="row">
                <div class="col-4">
                    <img src="<?php echo e($event['imgs'][0]); ?>" class="img img-fluid" alt=""
                        style="object-fit: cover; object-position: center;background-size: cover; height: 15rem; width: 100%">
                </div>
                <div class="col-8">
                    <h5><?php echo e($event['title']); ?></h5>
                    <p><?php echo e($event['content']); ?></p>
                    <p><b>Address</b> <?php echo e($event['address']); ?>, <?php echo e($event['city']); ?>, <?php echo e($event['zip']); ?></p>
                    <p><b>Start time</b> <?php echo e(date('d/m/Y H:i:s', $event['activityDate'][0]['from'] / 1000)); ?></p>
                    <p><b>End time</b> <?php echo e(date('d/m/Y H:i:s', $event['activityDate'][0]['to'] / 1000)); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/samuel/Documents/🔴 GitLocal/momsinla_partybemine_api/resources/views/past-events.blade.php ENDPATH**/ ?>